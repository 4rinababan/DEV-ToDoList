namespace ToDoServer.IServices
{
    public interface IVerifyPasswordHashService
    {
        bool VerifyPassword(string? password, byte[]? passwordHash, byte[]? passwordSalt);
    }
}
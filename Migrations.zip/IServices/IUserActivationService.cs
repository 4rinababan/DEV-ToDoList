using ToDoServer.Models.USER;

namespace ToDoServer.IServices
{
    public interface IUserActivationService
    {
        void AddActivation(UserActivation user);
        void UpdateUserActive(string activationCode);
    }
}
namespace ToDoServer.IServices
{
    public interface ICreatePasswordHashService
    {
        void CreatePasswordHash(string password, out byte[] passwordHash, out byte[] passwordSalt);
    }
}
using ToDoServer.Models.DTO;
using ToDoServer.Models.UserAccount;

namespace ToDoServer.IServices
{
    public interface IUserService
    {
        UserAccount Register(UserRegisterDTO request);
    }
}
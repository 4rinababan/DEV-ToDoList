using ToDoServer.Models.DTO;
using ToDoServer.Models.Identity;

namespace ToDoServer.IServices
{
    public interface IIdentityService
    {
        UserIdentityResponses? login(UserLoginDTO user);
        UserIdentityResponses? logout();
        void UpdateActivation(string UserName);
    }
}
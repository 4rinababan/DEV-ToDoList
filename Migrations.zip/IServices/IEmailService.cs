using ToDoServer.Models.DTO;

namespace ToDoServer.IServices
{
    public interface IEmailService
    {
        Task SendEmailAsync(UserRegisterDTO user, string subject,string? userId);
    }
}
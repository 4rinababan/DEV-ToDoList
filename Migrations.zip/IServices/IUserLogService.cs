using ToDoServer.Models.USER.Log;

namespace ToDoServer.IServices
{
    public interface IUserLogService
    {
        void AddUserLog(LogUsers log);
        LogUsers log(Object request,string conntroller,bool error);
    }
}
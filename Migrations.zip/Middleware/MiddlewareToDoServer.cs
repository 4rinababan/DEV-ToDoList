using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.Extensions.Logging;
using System;
using System.IO;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace ToDoServer.Middleware
{
    public class MiddlewareToDoServer
    {
        private readonly RequestDelegate _next;
        public MiddlewareToDoServer(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                //await ContainsSqlInjectionCharacters(context);
                await _next(context);
            }
            catch (Exception ex)
            {
                context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;

                if (ex is BadHttpRequestException)
                {
                    context.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                    await context.Response.WriteAsync("Bad Request - SQL injection detected.");
                    return;
                }

                if (ex is UnauthorizedAccessException)
                {
                    context.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
                    await context.Response.WriteAsync("Unauthorized");
                    return;
                }

                await context.Response.WriteAsync(ex.Message);
            }
        }

        // private async Task ContainsSqlInjectionCharacters(HttpContext context)
        // {
        //     string requestBody;
        //     using (StreamReader reader = new StreamReader(context.Request.Body))
        //     {
        //         requestBody = await reader.ReadToEndAsync();
        //     }

        //     dynamic requestData = null;

        //     try
        //     {
        //         requestData = JsonConvert.DeserializeObject<dynamic>(requestBody);
        //     }
        //     catch (JsonReaderException)
        //     {
        //         throw new BadHttpRequestException("Invalid JSON format");
        //     }

        //     string[] sqlInjectionCharacters = { "'", "\"", "--", ";", "/*", "*/", "UNION" };

        //     foreach (var item in requestData)
        //     {
        //         var propertyValue = Convert.ToString(item.Value);

        //         foreach (string sqlInjectionChar in sqlInjectionCharacters)
        //         {
        //             if (propertyValue.Contains(sqlInjectionChar))
        //             {
        //                 throw new BadHttpRequestException("SQL Injection Detected");
        //             }
        //         }
        //     }
        // }
    }
}

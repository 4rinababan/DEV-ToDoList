using ToDoServer.IRepositories;
using ToDoServer.IServices;
using ToDoServer.Models.USER.Log;
using ToDoServer.Services.Log;

namespace ToDoServer.Repositories
{
    public class UserLogRepository:IUserLogRepository
    {
        private readonly IUserLogService _userlog;
        public UserLogRepository(UserLogService logService)
        {
            _userlog=logService;   
        }
        public void AddLogUser(LogUsers log)
        {
            try
            {
                 _userlog.AddUserLog(log);
            }
            catch (Exception ex)
            {
                
                throw new Exception(ex.Message);
            }
           
        }

        public LogUsers log(Object request,string conntroller,bool error)
        {
            try
            {
                 return _userlog.log(request,conntroller,error);
            }
            catch (Exception ex)
            {
                
                throw new Exception(ex.Message);
            }
           
        }
    }
}

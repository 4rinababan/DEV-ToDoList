using ToDoServer.IRepositories;
using ToDoServer.IServices;
using ToDoServer.Models.DTO;
using ToDoServer.Models.Identity;

namespace ToDoServer.Repositories
{
    public class IdentityRepository:IIdentityRepository
    {
        private readonly IIdentityService _identity;
        public IdentityRepository(IIdentityService identityService)
        {
            _identity=identityService;
        }
        public UserIdentityResponses? login (UserLoginDTO request)
        {
            try
            {
                return  _identity.login(request);
            }
            catch (Exception)
            {            
                throw;
            }  
        }

        public UserIdentityResponses? logout ()
        {
            try
            {
                return _identity.logout();
            }
            catch (System.Exception ex) 
            {
                throw new Exception(ex.Message);
            }
        }

        public void UpdateActivation (string UserName)
        {
            try
            {
                _identity.UpdateActivation(UserName);
            }
            catch (System.Exception ex) 
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
using ToDoServer.IServices;
using ToDoServer.Models.UserAccount;
using ToDoServer.IRepositories;
using ToDoServer.Models.DTO;
using ToDoServer.Models;
using ToDoServer.DbHelper;

namespace ToDoServer.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly ICreatePasswordHashService _createPasswordService;
        private readonly IUserService _userService;
        private readonly DataContext _context;

        public UserRepository(ICreatePasswordHashService createPasswordHashService, IUserService userService, DataContext context)
        {
            _createPasswordService = createPasswordHashService;
            _context = context;
            _userService = userService;
        }

        public ContextResponse<UserAccount> Register(UserRegisterDTO request)
        {
            try
            {
                var userAccount = _userService.Register(request);
                var ContextResponse = new ContextResponse<UserAccount>
                {
                    IsError = false,
                    Message = "Success Created",
                    Data = userAccount
                };
                return ContextResponse;
            }
            catch (Exception exception)
            {
                return new ContextResponse<UserAccount> { IsError = true, Message = exception.Message, Data = null };
            }
        }
    }
}
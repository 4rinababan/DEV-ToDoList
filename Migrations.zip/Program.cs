using System.Text;
using HealthChecks.UI.Client;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using ToDoServer.DbHelper;
using ToDoServer.IRepositories;
using ToDoServer.IServices;
using ToDoServer.Middleware;
using ToDoServer.Repositories;
using ToDoServer.Services.Activation;
using ToDoServer.Services.Email;
using ToDoServer.Services.Log;
using ToDoServer.Services.UserSecurity;
using ToDoServer.TokenManager;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddDbContext<DataContext>(options =>
{
    options.UseNpgsql(builder.Configuration.GetConnectionString("EfPostgresDb"));
});

builder.Services.AddHealthChecks();

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddHttpContextAccessor();

builder.Services.AddAuthentication(auth =>
    {
        auth.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
        auth.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
    })
.AddJwtBearer(options =>
    {
        var secretKey = builder.Configuration.GetSection("JwtToken:SigningKey").Value;
        options.SaveToken = true;
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = builder.Configuration.GetSection("JwtToken:Issuer").Value,
            ValidateAudience = false,
            //ValidAudience = builder.Configuration.GetSection("JwtToken:Audience").Value,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secretKey))
        };
    });

builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<IIdentityService, IdentityService>();
builder.Services.AddScoped<ICreatePasswordHashService,CreatePasswordHashService>();
// builder.Services.AddScoped<IUSerLogService,UserLogService>();
builder.Services.AddScoped<IVerifyPasswordHashService,VerifyPasswordHashService>();
builder.Services.AddScoped<TokenConfiguration>();
builder.Services.AddScoped<IUserRepository, UserRepository>();
builder.Services.AddScoped<IIdentityRepository, IdentityRepository>();

// builder.Services.AddScoped<IUSerLogRepository,UserLogRepository>();
builder.Services.AddScoped<UserLogService>();
builder.Services.AddScoped<IUserLogRepository, UserLogRepository>();
builder.Services.AddScoped<IUserLogService, UserLogService>();
builder.Services.AddScoped<IEmailService,EmailService>();
builder.Services.AddScoped<IUserActivationService,USerActivationService>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();
app.UseMiddleware<MiddlewareToDoServer>();
app.MapControllers();
app.UseStatusCodePages();

// app.UseEndpoints(endpoints =>
// {
//     endpoints.MapControllers();
// });

app.MapHealthChecks("/health", new HealthCheckOptions
{
    ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
});
app.UseForwardedHeaders(new ForwardedHeadersOptions
{
    ForwardedHeaders = ForwardedHeaders.XForwardedFor |
    ForwardedHeaders.XForwardedProto
}); 

app.UseCors(builder => builder
    .AllowAnyOrigin()
    .AllowAnyMethod()
    .AllowAnyHeader());

app.Run();

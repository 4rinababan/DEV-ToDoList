﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ToDoServer.Migrations
{
    /// <inheritdoc />
    public partial class log8 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameTable(
                name: "user_account",
                schema: "public",
                newName: "user_account");

            migrationBuilder.AlterColumn<byte[]>(
                name: "password_salt",
                table: "user_account",
                type: "bytea",
                nullable: false,
                defaultValue: new byte[0],
                oldClrType: typeof(byte[]),
                oldType: "bytea",
                oldNullable: true);

            migrationBuilder.AlterColumn<byte[]>(
                name: "password_hash",
                table: "user_account",
                type: "bytea",
                nullable: false,
                defaultValue: new byte[0],
                oldClrType: typeof(byte[]),
                oldType: "bytea",
                oldNullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "public");

            migrationBuilder.RenameTable(
                name: "user_account",
                newName: "user_account",
                newSchema: "public");

            migrationBuilder.AlterColumn<byte[]>(
                name: "password_salt",
                schema: "public",
                table: "user_account",
                type: "bytea",
                nullable: true,
                oldClrType: typeof(byte[]),
                oldType: "bytea");

            migrationBuilder.AlterColumn<byte[]>(
                name: "password_hash",
                schema: "public",
                table: "user_account",
                type: "bytea",
                nullable: true,
                oldClrType: typeof(byte[]),
                oldType: "bytea");
        }
    }
}

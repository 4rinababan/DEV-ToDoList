﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ToDoServer.Migrations
{
    /// <inheritdoc />
    public partial class log7 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "public");

            migrationBuilder.RenameTable(
                name: "user_account",
                newName: "user_account",
                newSchema: "public");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameTable(
                name: "user_account",
                schema: "public",
                newName: "user_account");
        }
    }
}

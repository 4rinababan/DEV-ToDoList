﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ToDoServer.Migrations
{
    /// <inheritdoc />
    public partial class log9 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}

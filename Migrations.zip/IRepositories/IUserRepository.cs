using ToDoServer.Models;
using ToDoServer.Models.DTO;
using ToDoServer.Models.UserAccount;

namespace ToDoServer.IRepositories
{
    public interface IUserRepository
    {
        ContextResponse<UserAccount> Register(UserRegisterDTO request);
    }
}
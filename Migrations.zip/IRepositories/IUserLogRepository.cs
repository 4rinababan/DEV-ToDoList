using ToDoServer.Models.USER.Log;

namespace ToDoServer.IRepositories
{
    public interface IUserLogRepository
    {
        void AddLogUser(LogUsers log);
        LogUsers log(Object request,string conntroller,bool error);
    }
}
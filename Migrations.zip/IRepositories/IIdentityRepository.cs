using ToDoServer.Models.DTO;
using ToDoServer.Models.Identity;

namespace ToDoServer.IRepositories
{
    public interface IIdentityRepository
    {
        UserIdentityResponses? login (UserLoginDTO request);
        UserIdentityResponses? logout ();
        void UpdateActivation (string UserName);
    }
}
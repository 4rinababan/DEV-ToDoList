using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using ToDoServer.Models.USER.Identity;
using ToDoServer.Models.UserAccount;

namespace ToDoServer.TokenManager
{
    public class TokenConfiguration
    {
        private readonly IConfiguration _configuration;
        private JwtSecurityTokenHandler tokenHandler = new JwtSecurityTokenHandler();

        private TokenValidationParameters? validationParameters = new TokenValidationParameters();
        public TokenConfiguration(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public string CreateToken(UserAccount user)
        {
            var signingCredentials = new SigningCredentials(GetSecurityKey(GetJwtTokenSigningKey()), SecurityAlgorithms.HmacSha256);
            var claims = new[]
            {
                new Claim(ClaimTypes.Name, user.username),
                new Claim(ClaimTypes.Role, user.role),
                //new Claim("Id", user.id.ToString())
                // Add more claims as needed
            };

            var token = new JwtSecurityToken(
                issuer: _configuration.GetSection("JwtToken:Issuer").Value,
                audience: "",
                claims: claims,
                expires: DateTime.UtcNow.AddSeconds(5),
                signingCredentials: signingCredentials);

            var tokenHandler = new JwtSecurityTokenHandler();
            var tokenString = tokenHandler.WriteToken(token);
            return tokenString;
        }

        public bool ValidateToken(string token)
        {
            try
            {
                validationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = GetSecurityKey(GetJwtTokenSigningKey()),
                    ValidateIssuer = false,
                    // ValidIssuer = "https://localhost:5013/",
                    ValidateAudience = false
                };

                tokenHandler.ValidateToken(token, validationParameters, out SecurityToken validatedToken);
                if (validatedToken.ValidTo < DateTime.UtcNow)
                {
                    throw new TokenException("Token Expired");
                }

                if (validatedToken is JwtSecurityToken jwtToken)
                {
                    var username = jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value;
                    var role = jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role)?.Value;
                }
                else
                {
                    throw new TokenException("Token Invalid");
                }
                
                return true;
            }
            catch(Exception ex)
            {   
                if(ex is TokenException)
                {
                    throw new TokenException("Token Invalid");
                }
                throw new Exception(ex.Message);
            }
        }

        public TokenValidate? GetTokenClaim(string? token)
        {
            try
            {
                // TokenValidate tokenValidate = new TokenValidate();
                validationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = GetSecurityKey(GetJwtTokenSigningKey()),
                    ValidateIssuer = false,
                    // ValidIssuer = "https://localhost:5013/",
                    ValidateAudience = false
                };

                tokenHandler.ValidateToken(token, validationParameters, out SecurityToken validatedToken);
                if (validatedToken is JwtSecurityToken jwtToken)
                {
                    var tokenValidate = new TokenValidate
                    {
                        isValidToken=true,
                        // id = jwtToken.Claims.FirstOrDefault(c => c.Type == "Id")?.Value,
                        username = jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value,
                        role = jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role)?.Value
                    };
                    return  tokenValidate;                
                }
                else
                {
                    throw new TokenException("Token Invalid");
                }
            }
            catch(Exception exception)
            {
                throw new TokenException(exception.Message);
            }
        }

        private SymmetricSecurityKey GetSecurityKey(string secretKey)
        {
            return new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secretKey));
        }

        public string? GetJwtTokenSigningKey()
        {
            return _configuration.GetSection("JwtToken:SigningKey").Value;
        }
    }
}

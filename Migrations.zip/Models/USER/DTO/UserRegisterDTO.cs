using System.ComponentModel.DataAnnotations;

namespace ToDoServer.Models.DTO
{
    public class UserRegisterDTO
    {
        [Required]
        public string username { get; set; } = string.Empty;
        [Required]
        public string email { get; set; } = string.Empty;
        [Required]
        public string fullname { get; set; } = string.Empty;
        [Required]
        public string password { get; set; } = string.Empty;
        [Required]
        public string role { get; set; } = string.Empty;
    }

}
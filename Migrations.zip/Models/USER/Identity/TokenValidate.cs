namespace ToDoServer.Models.USER.Identity
{
    public class TokenValidate
    {
        public bool isValidToken{get;set;}
        // public string? id{get;set;} 
        public string? username {get;set;}
        public string? role{get;set;}
    }
}
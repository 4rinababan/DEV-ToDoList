using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ToDoServer.Models.UserAccount
{
    [Table("user_account")]
    public class UserAccount
    {
        public Guid id { get; set; }
        public string username { get; set; } = string.Empty;
        public string fullname { get; set; } = string.Empty;
        public byte[]? password_hash { get; set; }
        public byte[]? password_salt { get; set; }
        public string role { get; set; } = string.Empty;
        public int isactive { get; set; }
        public int isused { get; set; }
        public int islock { get; set; }
        public DateTime created_date { get; set; }
        public string created_by { get; set; } = string.Empty;
        public DateTime? updated_date { get; set; }
        public string updated_by { get; set; } = string.Empty;
    }

}
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ToDoServer.Models.USER
{
    [Table("user_activation")]
    public class UserActivation
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [Column("user_id")]
        public string? UserId { get; set; }

        [Required]
        [Column("activation_code")]
        [MaxLength(100)]
        public string? ActivationCode { get; set; }

        [Required]
        [Column("is_activated")]
        public bool IsActivated { get; set; }

        [Required]
        [Column("expire_time")]
        public DateTime ExpireTime { get; set; }

        [Required]
        [Column("created_at")]
        public DateTime CreatedAt { get; set; }
        [Required]
        [Column("created_by")]
        public string? CreatedBy { get; set; }

    }
}
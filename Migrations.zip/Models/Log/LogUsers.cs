using System.ComponentModel.DataAnnotations.Schema;

namespace ToDoServer.Models.USER.Log
{
    [Table("log_user")]
    public class LogUsers
    {
        [Column("id")]
        public Guid Id {get;set;}
        [Column("ip_address")]
        public string? IpAddress {get;set;}
        [Column("mac_address")]
        public string? MacAddress {get;set;}
        [Column("api")]
        public string? Api {get;set;}
        [Column("is_error")]
        public bool IsError {get;set;}
        [Column("payload")]
        public List<string>? Payload {get;set;}
        [Column("created_by")]
        public string? CreatedBy {get;set;}
        [Column("created_date")]
        public DateTime CreatedDate{get;set;}

    }
}
using System.Diagnostics;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ToDoServer.IRepositories;
using ToDoServer.Models;
using ToDoServer.Models.DTO;
using ToDoServer.Models.Identity;
using ToDoServer.Models.USER.Log;
using ToDoServer.Models.UserAccount;
using ToDoServer.IServices;

namespace ToDoServer.Controllers;

[ApiController]
[Authorize]
public class AuthController : ControllerBase
{

    private readonly ILogger<AuthController> _logger;
    private readonly IUserRepository _userRepository;
    private readonly IIdentityRepository _identityRepository;
    private readonly IUserActivationService _activation;
    private readonly IEmailService _email;
    private IHttpContextAccessor _httpContext;
    private IUserLogRepository _userLogRepository;
    private LogUsers _log = new LogUsers();


    public AuthController(IUserActivationService activation, ILogger<AuthController> logger, IUserLogRepository userLogRepository, IUserRepository userRepository, IIdentityRepository identityRepository, IEmailService email, IHttpContextAccessor httpContextAccessor)
    {
        _logger = logger;
        _userRepository = userRepository;
        _identityRepository = identityRepository;
        _httpContext = httpContextAccessor;
        _userLogRepository = userLogRepository;
        _email = email;
        _activation = activation;
    }

    [HttpPost]
    [AllowAnonymous]
    [Route("[controller]/register")]
    public async Task<ActionResult> Register(UserRegisterDTO request)
    {
        try
        {
            var responseContext = await Task.Run(() => _userRepository.Register(request));
            _log = _userLogRepository.log(request, ControllerContext.RouteData.Values["controller"]?.ToString() + "/register" ?? string.Empty, false);
            _userLogRepository.AddLogUser(_log);
            if (!responseContext.IsError)
            {
                await _email.SendEmailAsync(request, "Registration", responseContext.Data.id.ToString());
                return Created("", responseContext);
            }
            return BadRequest(responseContext);
        }
        catch (Exception ex)
        {
            _log = _userLogRepository.log(request, ControllerContext.RouteData.Values["controller"]?.ToString() + "/register" ?? string.Empty, true);
            _userLogRepository.AddLogUser(_log);
            return BadRequest(new ContextResponse<UserAccount> { IsError = false, Message = ex.Message, Data = null });
        }
    }

    [HttpGet]
    [AllowAnonymous]
    [Route("[controller]/active/{Username}/{ActivationCode}")]
    public async Task<ActionResult> activation(string Username, string ActivationCode)
    {
        try
        {
            await Task.Run(() => _activation.UpdateUserActive(ActivationCode));
            _identityRepository.UpdateActivation(Username);
            return Ok($"Username {Username} Succes Activated Please Login");
        }
        catch (System.Exception exception)
        {
            return BadRequest(exception.Message);
        }
    }

    [HttpPost]
    [AllowAnonymous]
    [Route("[controller]/Login")]
    public async Task<ActionResult> Login(UserLoginDTO request)
    {
        try
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            var responseContext = await Task.Run(() => _identityRepository.login(request));
            stopwatch.Stop();
            TimeSpan executionTime = stopwatch.Elapsed;
            double seconds = executionTime.TotalSeconds;
            _log = _userLogRepository.log(request, ControllerContext.RouteData.Values["controller"]?.ToString() + "/login" ?? string.Empty, responseContext.IsAuthSuccessfull ? false : true);
            _userLogRepository.AddLogUser(_log);
            return responseContext.IsAuthSuccessfull ? Ok(new { responseContext, ExecTime = seconds + " ms" }) : BadRequest(responseContext);
        }

        catch (Exception exception)
        {
            _log = _userLogRepository.log(request, ControllerContext.RouteData.Values["controller"]?.ToString() + "/login" ?? string.Empty, true);
            _userLogRepository.AddLogUser(_log);
            return BadRequest(new UserIdentityResponses { IsAuthSuccessfull = false, ErrorMessage = exception.Message, Token = null });
        }
    }

    [HttpPost]
    [AllowAnonymous]
    [Route("[controller]/Logout")]
    public async Task<ActionResult> Logout()
    {
        try
        {
            var responseContext = await Task.Run(() => _identityRepository.logout());
            _log = _userLogRepository.log("logout", ControllerContext.RouteData.Values["controller"]?.ToString() + "/logout" ?? string.Empty, false);
            _userLogRepository.AddLogUser(_log);
            return responseContext.IsAuthSuccessfull ? Ok("Succes Logout") : BadRequest(responseContext.ErrorMessage);
        }
        catch (Exception exception)
        {
            _log = _userLogRepository.log("logout", ControllerContext.RouteData.Values["controller"]?.ToString() + "/logout" ?? string.Empty, true);
            _userLogRepository.AddLogUser(_log);
            if (exception is IdentityException)
            {
                return BadRequest(new UserIdentityResponses { IsAuthSuccessfull = false, ErrorMessage = $"{exception.Message}." });
            }
            return BadRequest(new UserIdentityResponses { IsAuthSuccessfull = false, ErrorMessage = exception.Message, Token = null });
        }
    }
}

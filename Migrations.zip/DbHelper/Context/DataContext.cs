using Microsoft.EntityFrameworkCore;
using ToDoServer.Models.USER.Log;
using ToDoServer.Models.UserAccount;
using System;
using System.Linq;
using ToDoServer.Models.USER;

namespace ToDoServer.DbHelper
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {
        }

        public DbSet<UserAccount> user_account { get; set; }
        public DbSet<LogUsers> user_log { get; set; }
        public DbSet<UserActivation> user_activation { get; set; }

        public override int SaveChanges()
        {
            var entities = ChangeTracker.Entries()
                .Where(e => e.State == EntityState.Added || e.State == EntityState.Modified)
                .ToList();

            var currentTime = DateTime.UtcNow;

            foreach (var entity in entities)
            {
                if (entity.Entity is UserAccount user_account && entity.State == EntityState.Added)
                {
                    var existingUser = this.Set<UserAccount>().FirstOrDefault(u => u.username == user_account.username);
                    if (existingUser != null)
                    {
                        if (existingUser.isused == 1)
                        {
                            throw new IdentityException($"User '{existingUser.username}' is used");
                        }
                        else
                        {
                            throw new IdentityException($"Username '{existingUser.username}' already exists");
                        }
                    }
                    else
                    {
                        user_account.created_date = currentTime;
                    }
                }
            }

            return base.SaveChanges();
        }
    }
}

using System.Net;
using System.Net.Mail;
using ToDoServer.IServices;
using ToDoServer.Models.DTO;
using ToDoServer.Models.USER;
using ToDoServer.Models.UserAccount;

namespace ToDoServer.Services.Email
{
    public class EmailService:IEmailService
    {
        private readonly IUserActivationService _userActivation;
        private readonly IHttpContextAccessor  _httpContextAccessor;
        public EmailService(IUserActivationService userActivation, IHttpContextAccessor httpContext)
        {
            _userActivation=userActivation;
            _httpContextAccessor=httpContext;
        }
        public Task SendEmailAsync(UserRegisterDTO user, string subject,string? userId)
        {
            var httpContext = _httpContextAccessor.HttpContext;
            var root = $"{httpContext?.Request.Scheme}://{httpContext?.Request.Host}";
            string activationCode = Guid.NewGuid().ToString();
            var activationLink = $"{root}/auth/active/{user.username}/{activationCode}";
            UserActivation activation = new UserActivation
            {
                ActivationCode=activationCode,
                IsActivated=false,
                UserId=userId,
                ExpireTime=DateTime.UtcNow.AddMinutes(5),
                CreatedAt=DateTime.UtcNow,
                CreatedBy="System"
            };
            _userActivation.AddActivation(activation);
            var client = new SmtpClient("smtp.office365.com", 587)
            {
                EnableSsl = true,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential("arinababan@outlook.com", "ar1aja123")
            };
            var mailMessage = new MailMessage(from: "arinababan@outlook.com",
                to: user.email,
                subject,
                body: GetBody(activationLink, user.username))
            {
                IsBodyHtml = true
            };
            return client.SendMailAsync(mailMessage);
                                
        }

        private string GetBody(string linkActivation,string username)
        {
            string body=$@"
                            <!DOCTYPE html>
                <html>
                <head>
                    <meta charset='UTF-8'>
                    <title>Email Confirmation</title>
                    <style>
                        /* Gaya email */
                        body {{
                            font-family: Arial, sans-serif;
                        }}
                        .container {{
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                            background-color: #f5f5f5;
                            border-radius: 5px;
                        }}
                        h2 {{
                            color: #333333;
                            margin-top: 0;
                        }}
                        .btn {{
                            display: inline-block;
                            padding: 10px 20px;
                            background-color: #4caf50;
                            color: #ffffff;
                            text-decoration: none;
                            border-radius: 3px;
                            margin-top: 20px;
                        }}
                        p {{
                            color: #333333;
                        }}
                        .footer {{
                            margin-top: 40px;
                            text-align: center;
                            color: #999999;
                        }}
                    </style>
                    </head>
                    <body>
                        <div class='container'>
                            <h2>Dear {username},</h2>

                            <p>Thank you for registering on our website! We're excited to have you as part of our community. To complete your registration, please click the button below to verify your email address:</p>

                            <a href='{linkActivation}' class='btn'>Verify Email</a>

                            <p><strong>Why verify your email address?</strong></p>
                            <ul>
                                <li>Receive important updates and notifications</li>
                                <li>Reset your password if needed</li>
                                <li>Unlock additional features and personalized experiences</li>
                            </ul>

                            <p><strong>Haven't registered on our website?</strong></p>
                            <p>If you did not sign up for an account on our platform, please disregard this email. No further action is required.</p>

                            <p>Please note:</p>
                            <ul>
                                <li>This link will expire in [expiration time].</li>
                                <li>If the button above doesn't work, you can copy and paste the following link into your browser:</li>
                            </ul>

                            <p>{linkActivation}</p>

                            <p>If you have any questions or need assistance, please don't hesitate to reach out to our support team at [Support Email]. We're here to help!</p>
            
                            <p>Thank you,</p>
                            <p>DJEGES SOLUTION Team</p>
                        </div>
                    </body>
                </html>";
                return body;
        }
    }
}
using System.Net;
using System.Net.NetworkInformation;
using Newtonsoft.Json;
using ToDoServer.DbHelper;
using ToDoServer.IServices;
using ToDoServer.Models.USER.Log;

namespace ToDoServer.Services.Log
{
    public class UserLogService:IUserLogService
    {
        private readonly DataContext _context;
        private readonly IHttpContextAccessor _httpContext;

        public UserLogService(DataContext context,IHttpContextAccessor httpContext)
        {
            _context=context;
            _httpContext=httpContext;
        }

        public void AddUserLog(LogUsers log)
        {
            try
            {
                _context.user_log.Add(log);
                _context.SaveChanges();
            }
            catch (Exception exception)
            {
                throw new Exception(exception.Message);
            }
            
        }

        public LogUsers log(Object request,string conntroller,bool error)
        {
            LogUsers dataLog = new LogUsers
            {
                Id=Guid.NewGuid(),
                IpAddress=GetIpClient(),
                MacAddress=GetMacClient(),
                Api=conntroller,
                IsError=error,
                Payload=new List<string> { JsonConvert.SerializeObject(request) },
                CreatedBy="System",
                CreatedDate=DateTime.UtcNow
            };
            return dataLog;
        }

        public string? GetIpClient()
        {
            if(GetHttpContextInformation()=="::1")
            {
                return Dns.GetHostEntry(Dns.GetHostName()).AddressList[1].ToString();
            }
             //var currentUser =_httpContext.HttpContext.User.FindFirst("username").ToString();
            return GetHttpContextInformation();
        }

        public string? GetMacClient()
        {
            var networkInterfaces = NetworkInterface.GetAllNetworkInterfaces();
            var ethernetInterface = networkInterfaces.FirstOrDefault(nic => nic.NetworkInterfaceType == NetworkInterfaceType.Ethernet);
            if (ethernetInterface != null)
            {
                var macAddressBytes = ethernetInterface.GetPhysicalAddress().GetAddressBytes();
                return string.Join(":", macAddressBytes.Select(b => b.ToString("X2")));
            }
            return null;
        }

        public string? GetHttpContextInformation()
        {
            return _httpContext?.HttpContext?.Connection?.RemoteIpAddress?.ToString();
        }
    }
}
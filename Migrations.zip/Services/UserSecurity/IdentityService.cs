using ToDoServer.Models.DTO;
using ToDoServer.Models.UserAccount;
using ToDoServer.IServices;
using ToDoServer.Models.Identity;
using ToDoServer.TokenManager;
using ToDoServer.DbHelper;

namespace ToDoServer.Services.UserSecurity
{
    public class IdentityService:IIdentityService
    {
        private readonly IVerifyPasswordHashService _verifyPassword;
        private readonly DataContext _context;
        private readonly TokenConfiguration _tokenConfiguration;
        private readonly IHttpContextAccessor  _httpContext;

        public IdentityService(TokenConfiguration tokenConfiguration, IVerifyPasswordHashService verifyPasswordHash,DataContext context,IHttpContextAccessor httpContext)
        {
            _context=context;
            _verifyPassword=verifyPasswordHash;
            _tokenConfiguration=tokenConfiguration;
            _httpContext=httpContext;
        }
        public UserIdentityResponses? login(UserLoginDTO user)
        {
            try
            {        
                var data = _context.user_account.FirstOrDefault(d => d.username.Equals(user.username));
                if(data==null)
                {
                    return new UserIdentityResponses { IsAuthSuccessfull = false,ErrorMessage=$"User {user.username} Not Exists", Token = null };
                }
                CheckUserStatus(data);
                if (!_verifyPassword.VerifyPassword(user.password, data?.password_hash, data?.password_salt))
                {
                    return new UserIdentityResponses { IsAuthSuccessfull = false,ErrorMessage=$"Wrong Password for Username {user.username}", Token = null };
                }
                UpdateUserUsedStatus(data,false);               
                var token = _tokenConfiguration.CreateToken(new UserAccount { username = data.username, role = data.role });
                return new UserIdentityResponses { IsAuthSuccessfull = true, Token = token };
            }
            catch (IdentityException )
            {
                throw ;
            }
            catch(Exception)
            {
                throw;
            }
        }

        public UserIdentityResponses? logout()
        {
            try
            {
                var token = _httpContext?.HttpContext?.Request.Headers["Authorization"].ToString().Replace("Bearer ", "");
                var TokenClaim = _tokenConfiguration.GetTokenClaim(token);
                var user = _context.user_account.First(x=> x.username==TokenClaim.username);
                UpdateUserUsedStatus(user,true);
                return new UserIdentityResponses { IsAuthSuccessfull = true, Token = null };
            }
            catch (IdentityException exception)
            {
                return new UserIdentityResponses { IsAuthSuccessfull = false, ErrorMessage = $"{exception.Message}." };
            }
            catch (System.Exception exception)
            {
                return new UserIdentityResponses { IsAuthSuccessfull = false, ErrorMessage = $"{exception.Message}." };
            }
        }

        private void CheckUserStatus(UserAccount? user)
        {
            if (user?.isused > 0)
            {
                throw new IdentityException($"User '{user.username}' is used");
            }
            if (user?.islock > 0)
            {
                throw new IdentityException($"User '{user.username}' is locked");
            }
            if (user?.isactive == 0)
            {
                throw new IdentityException($"User '{user.username}' not active Please Confirm Email");
            }
        }

        private void UpdateUserUsedStatus(UserAccount user,bool logout)
        {
            if(logout)
                user.isused = 0;
            else
                user.isused = 1;
            _context.SaveChanges();
        }

        public void UpdateActivation(string Username)
        {
            var user =  _context.user_account.FirstOrDefault(u => u.username == Username);
            if (user != null)
            {
                user.isactive = 1;
                _context.SaveChanges();
            }
        }

    }
}

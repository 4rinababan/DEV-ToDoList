using ToDoServer.DbHelper;
using ToDoServer.IServices;
using ToDoServer.Models.DTO;
using ToDoServer.Models.UserAccount;

namespace ToDoServer.Services.UserSecurity
{
    public class UserService:IUserService
    {
        private readonly ICreatePasswordHashService _createPasswordService;
        private readonly DataContext _context;

        public UserService(ICreatePasswordHashService createPasswordHashService,DataContext context)
        {
            _context=context;
            _createPasswordService=createPasswordHashService;
        }

        public UserAccount Register(UserRegisterDTO request)
        {
            try
            {
                _createPasswordService.CreatePasswordHash(request.password, out byte[] passwordHash, out byte[] passwordSalt);
                UserAccount user = new UserAccount
                {
                    id= Guid.NewGuid(),
                    username = request.username,
                    role = request.role,
                    fullname = request.fullname,
                    password_salt = passwordHash,
                    password_hash = passwordSalt,
                    created_date = DateTime.UtcNow,
                    created_by="System"
                };     
                _context.user_account.Add(user);
                _context.SaveChanges();
                return user;
            }
            catch (Exception exception)
            {                
                throw new Exception(exception.Message);
            }
            
        }

    }
}